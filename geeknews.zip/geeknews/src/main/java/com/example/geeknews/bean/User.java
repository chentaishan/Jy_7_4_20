package com.example.geeknews.bean;

public class User {
}
