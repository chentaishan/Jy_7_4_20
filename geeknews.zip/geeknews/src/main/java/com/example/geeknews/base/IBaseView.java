package com.example.geeknews.base;

public interface IBaseView {
    void errorUI(String error);
}
